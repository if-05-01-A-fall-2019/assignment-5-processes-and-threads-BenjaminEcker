
import java.util.Scanner;
import java.io.IOException;
import java.io.InputStream;
import static java.time.Clock.system;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author benja
 */
public class CommandRunner {
    public static void main(String[] args) throws InterruptedException, IOException{
        Scanner s= new Scanner(System.in);
        String input=s.nextLine();
        String[] commands=input.split("&");
        for (String command : commands) {
            runCmd(command);   
        }
    }
    public static void runCmd(String command) throws IOException, InterruptedException{
        try{
            Process p= Runtime.getRuntime().exec("cmd /c "+command);
            p.waitFor();
            InputStream s=p.getInputStream();
            int b = s.read();
            while (b != -1) {
                System.out.print((char)b);
                b = s.read();
            }
            System.out.println();
            p.destroy();
        }
        catch(IOException e) {
            e.printStackTrace();
	}
        catch(InterruptedException e) {
            e.printStackTrace();
        }
    }
}
